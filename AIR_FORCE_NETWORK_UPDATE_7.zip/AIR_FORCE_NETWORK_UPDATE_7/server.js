const fs = require('fs');
const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'air-force-users.json');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true, credentials: false }, maxHttpBufferSize: 1e5 });
app.use(express.json({ limit: '20kb' }));
app.use(express.static(__dirname));

let db = { users: {} };
try { if (fs.existsSync(DATA_FILE)) db = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch (e) { console.error('Не удалось прочитать базу, будет создана новая:', e.message); }
if (!db.users || typeof db.users !== 'object') db = { users: {} };
const socketsByUser = new Map();
const rooms = new Map();
const saveDb = () => fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
const cleanNick = v => String(v || '').trim().replace(/[^\p{L}\p{N}_\-. ]/gu, '').slice(0, 18);
function ensureUser(id) {
  if (!id || typeof id !== 'string' || id.length > 100) throw new Error('Неизвестный профиль');
  if (!db.users[id]) {
    db.users[id] = { id, nickname: 'Пилот' + Math.floor(1000 + Math.random() * 9000), friends: [], incoming: [], outgoing: [], createdAt: Date.now() };
    saveDb();
  }
  return db.users[id];
}
function findUserByNick(nick) { const n = String(nick || '').trim().toLocaleLowerCase(); return Object.values(db.users).find(u => u.nickname.toLocaleLowerCase() === n); }
function publicUser(u) { return { id: u.id, nickname: u.nickname }; }
function stateFor(u) {
  return { user: publicUser(u), friends: u.friends.map(id => db.users[id]).filter(Boolean).map(publicUser), requests: u.incoming.map(id => db.users[id]).filter(Boolean).map(publicUser) };
}
function roomSnapshot(room, forId) {
  const others = [...room.players.values()].filter(p => p.id !== forId);
  return { code: room.code, players: Object.fromEntries([...room.players].map(([id,p]) => [id, { id, nickname: p.nickname, x: p.x, y: p.y, color: p.color, sword: p.sword }])), hits: room.scores.get(forId) || 0, botHits: others.length ? Math.max(...others.map(p => room.scores.get(p.id) || 0)) : 0 };
}
function broadcastRoom(room, event = 'room:update') {
  for (const p of room.players.values()) {
    const sock = io.sockets.sockets.get(p.socketId);
    if (sock) sock.emit(event, roomSnapshot(room, p.id));
  }
}
function leaveRoom(socket) {
  const roomCode = socket.data.roomCode;
  if (!roomCode) return;
  const room = rooms.get(roomCode);
  socket.data.roomCode = null;
  if (!room) return;
  room.players.delete(socket.data.userId);
  room.scores.delete(socket.data.userId);
  socket.leave(roomCode);
  if (room.players.size === 0) rooms.delete(roomCode);
  else broadcastRoom(room);
  socket.emit('room:left');
}
function makeCode() { let code; do { code = Math.random().toString(36).slice(2, 7).toUpperCase(); } while (rooms.has(code)); return code; }

app.get('/api/state', (req, res) => {
  try { const u = ensureUser(String(req.query.deviceId || '')); res.json(stateFor(u)); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/profile', (req, res) => {
  try {
    const u = ensureUser(String(req.body.deviceId || ''));
    const nickname = cleanNick(req.body.nickname);
    if (nickname.length < 3) return res.status(400).json({ error: 'Ник должен быть от 3 до 18 символов' });
    const taken = findUserByNick(nickname);
    if (taken && taken.id !== u.id) return res.status(409).json({ error: 'Этот ник уже занят. Выбери другой.' });
    u.nickname = nickname; saveDb(); res.json({ user: publicUser(u) });
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/friends/find', (req, res) => {
  try {
    const me = ensureUser(String(req.body.deviceId || ''));
    const found = findUserByNick(cleanNick(req.body.nickname));
    if (!found) return res.status(404).json({ error: 'Игрок с таким ником не найден' });
    if (found.id === me.id) return res.json({ user: publicUser(found) });
    res.json({ user: publicUser(found), alreadyFriend: me.friends.includes(found.id) });
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/friends/request', (req, res) => {
  try {
    const me = ensureUser(String(req.body.deviceId || ''));
    const target = db.users[String(req.body.targetId || '')];
    if (!target) return res.status(404).json({ error: 'Игрок не найден' });
    if (target.id === me.id) return res.status(400).json({ error: 'Нельзя добавить самого себя' });
    if (me.friends.includes(target.id)) return res.status(409).json({ error: 'Вы уже друзья' });
    if (target.incoming.includes(me.id)) return res.status(409).json({ error: 'Заявка уже отправлена' });
    if (me.incoming.includes(target.id)) return res.status(409).json({ error: 'Этот игрок уже отправил тебе заявку — прими её' });
    target.incoming.push(me.id); me.outgoing.push(target.id); saveDb();
    for (const sid of socketsByUser.get(target.id) || []) io.to(sid).emit('friend:request', { from: publicUser(me) });
    res.json({ ok: true });
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/friends/respond', (req, res) => {
  try {
    const me = ensureUser(String(req.body.deviceId || ''));
    const fromId = String(req.body.requestId || '');
    const from = db.users[fromId];
    if (!from || !me.incoming.includes(fromId)) return res.status(404).json({ error: 'Заявка не найдена' });
    me.incoming = me.incoming.filter(x => x !== fromId); from.outgoing = from.outgoing.filter(x => x !== me.id);
    if (req.body.accept) { if (!me.friends.includes(fromId)) me.friends.push(fromId); if (!from.friends.includes(me.id)) from.friends.push(me.id); }
    saveDb(); res.json({ ok: true, state: stateFor(me) });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

io.on('connection', socket => {
  try {
    const u = ensureUser(String(socket.handshake.auth?.deviceId || ''));
    socket.data.userId = u.id; socket.data.nickname = u.nickname;
    if (!socketsByUser.has(u.id)) socketsByUser.set(u.id, new Set());
    socketsByUser.get(u.id).add(socket.id);
  } catch (e) { socket.disconnect(true); return; }

  socket.on('room:create', () => {
    leaveRoom(socket);
    const code = makeCode();
    const room = { code, players: new Map(), scores: new Map(), finished: false };
    rooms.set(code, room); socket.join(code); socket.data.roomCode = code;
    const id = socket.data.userId;
    room.players.set(id, { id, nickname: socket.data.nickname, socketId: socket.id, x: 170, y: 215, color: '#35aaff', sword: '#35aaff' }); room.scores.set(id, 0);
    socket.emit('room:joined', roomSnapshot(room, id));
  });
  socket.on('room:join', data => {
    const code = String(data?.code || '').trim().toUpperCase(); const room = rooms.get(code);
    if (!room) return socket.emit('room:error', { message: 'Комната не найдена. Проверь код.' });
    if (room.players.size >= 8) return socket.emit('room:error', { message: 'Комната заполнена (максимум 8 пилотов).' });
    if (socket.data.roomCode) leaveRoom(socket);
    const id = socket.data.userId;
    if (room.players.has(id)) return socket.emit('room:error', { message: 'Ты уже в этой комнате.' });
    socket.join(code); socket.data.roomCode = code;
    const red = room.players.size % 2 === 1;
    room.players.set(id, { id, nickname: socket.data.nickname, socketId: socket.id, x: red ? 720 : 170, y: red ? 215 : 215, color: red ? '#ff4d57' : '#35aaff', sword: red ? '#ff394e' : '#35aaff' }); room.scores.set(id, 0);
    broadcastRoom(room);
    socket.emit('room:joined', roomSnapshot(room, id));
  });
  socket.on('room:move', pos => {
    const room = rooms.get(socket.data.roomCode); if (!room) return;
    const p = room.players.get(socket.data.userId); if (!p) return;
    p.x = Math.max(45, Math.min(855, Number(pos?.x) || p.x)); p.y = Math.max(95, Math.min(380, Number(pos?.y) || p.y));
    broadcastRoom(room);
  });
  socket.on('room:attack', () => {
    const room = rooms.get(socket.data.roomCode); if (!room || room.finished) return;
    const me = room.players.get(socket.data.userId); if (!me) return;
    const now = Date.now(); if (now - (me.lastAttack || 0) < 450) return; me.lastAttack = now;
    let target = null, best = 150;
    for (const p of room.players.values()) { if (p.id === me.id) continue; const d = Math.hypot(p.x - me.x, p.y - me.y); if (d < best) { best = d; target = p; } }
    if (!target) { socket.emit('room:hit', { hits: room.scores.get(me.id) || 0, botHits: 0, message: 'Подлети ближе к самолёту соперника!' }); return; }
    room.scores.set(me.id, (room.scores.get(me.id) || 0) + 1);
    const won = room.scores.get(me.id) >= 3; if (won) room.finished = true;
    broadcastRoom(room, 'room:update');
    for (const p of room.players.values()) {
      const s = io.sockets.sockets.get(p.socketId);
      if (s) s.emit('room:hit', { hits: room.scores.get(p.id) || 0, botHits: room.scores.get(me.id === p.id ? target.id : me.id) || 0, message: p.id === me.id ? '⚡ Ты коснулся соперника мечом!' : (p.id === target.id ? '⚡ Твой самолёт задели мечом!' : 'Попадание в комнате!') });
      if (won && s) s.emit('room:finished', { winner: me.id, nickname: me.nickname });
    }
  });
  socket.on('room:invite', data => {
    const targetId = String(data?.targetId || ''); const code = String(data?.code || '').toUpperCase();
    if (code !== socket.data.roomCode || !rooms.has(code)) return socket.emit('room:error', { message: 'Сначала создай комнату.' });
    const target = db.users[targetId]; if (!target || !socket.data.userId) return socket.emit('room:error', { message: 'Друг не найден.' });
    let sent = false; for (const sid of socketsByUser.get(targetId) || []) { io.to(sid).emit('room:invite', { code, from: socket.data.nickname }); sent = true; }
    socket.emit('room:invite:result', { ok: sent, message: sent ? 'Приглашение отправлено!' : 'Друг сейчас не в сети. Отправь ему код комнаты.' });
  });
  socket.on('room:leave', () => leaveRoom(socket));
  socket.on('disconnect', () => {
    leaveRoom(socket);
    const set = socketsByUser.get(socket.data.userId); if (set) { set.delete(socket.id); if (!set.size) socketsByUser.delete(socket.data.userId); }
  });
});

server.listen(PORT, () => console.log(`AIR FORCE server listening on http://localhost:${PORT}`));
